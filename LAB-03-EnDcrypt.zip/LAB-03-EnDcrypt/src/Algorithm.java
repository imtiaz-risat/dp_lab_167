public interface Algorithm {
    public String encrypt(String message);
    public String decrypt(String message);  
}
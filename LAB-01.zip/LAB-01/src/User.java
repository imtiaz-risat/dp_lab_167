public abstract class User{
    private int id;
    private String name;
    private String location;
    private double rating;
}
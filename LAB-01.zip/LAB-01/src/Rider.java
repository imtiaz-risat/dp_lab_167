public class Rider extends User {
    private PaymentMethod preferredPaymentMethod;

    public void setPreferredPaymentMethod(PaymentMethod paymentMethod){
        this.preferredPaymentMethod = paymentMethod;
    }

    public void requestRide(RideType rideType, String pickUpLocation, String dropOffLocation){
        //
    }

    public void rateDriver(Driver driver, double rating){
        //
    }

    public void makePayment(Trip trip){
        if(preferredPaymentMethod != null){
            Double fare = trip.getFare();
            preferredPaymentMethod.processPayment(fare);
        }else{
            // no prefered payment method
        }
    }
}

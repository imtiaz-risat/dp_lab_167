public class Driver extends User{
    private String vehicleType;
    private boolean availability;

    public void acceptRide(Trip trip){
        //
    }

    public void rateRider(Rider rider, double rating){
        //
    }

    public void updateLocation(String newLocation){
        //
    }

    public void startTrip(Trip trip){
        //
    }

}

public class Admin {
    private int id;
    private String name;
    private String role;

    public void manageDriver(Driver driver){}

    public void manageRider(Rider rider){
        //
    }

    public void viewTripHistory(){}


    public void handleDispute(){}

}

public class Trip {
    private int id;
    private String pickupLocation;
    private String dropOffLocation;
    private RideType rideType;
    private String Status;
    private Double fare;
    private Double distance;
    // notification service thakbe

    // Ekta constructor thakbe parameter (driver, rider, rideType)
    public Trip(Driver driver, Rider rider, RideType rideType){
        
    }

    public void calculateFare(){    
        this.fare = rideType.calculateFare(this.distance, "time-of-day");    
    }

    public void assignDriver(){
        // 
    }

    public void completeTrip(){
        // ekhan theke driver rider er preffered notificationService use hbe
    }

    public Double getFare(){
        return this.fare;
    }

}
